
export default function Payment(){

 return(
  <main>

   <h1>Payment</h1>

   <div className="card">

    This site uses manual Interac e-Transfer.

    <br/><br/>

    Send payment to:

    <b>mr.pelkie@gmail.com</b>

    <br/><br/>

    Include your order or service name in the note.

   </div>

  </main>
 )
}
