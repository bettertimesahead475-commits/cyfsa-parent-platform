
export default function Navigation(){
 return(
  <div style={{background:"#0f172a",color:"white",padding:"16px"}}>
   <a href="/" style={{marginRight:16,color:"white"}}>Home</a>
   <a href="/rights" style={{marginRight:16,color:"white"}}>Rights</a>
   <a href="/five-day-rule" style={{marginRight:16,color:"white"}}>5 Day Rule</a>
   <a href="/resources" style={{marginRight:16,color:"white"}}>Resources</a>
   <a href="/analyzer" style={{marginRight:16,color:"white"}}>Analyzer</a>
   <a href="/lawyer-intake" style={{marginRight:16,color:"white"}}>Lawyer Intake</a>
   <a href="/payment" style={{color:"white"}}>Payment</a>
  </div>
 )
}
