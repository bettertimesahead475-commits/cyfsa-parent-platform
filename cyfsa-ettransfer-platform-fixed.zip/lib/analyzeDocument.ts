
import rules from "./analyzerRules.json"

export function analyzeDocument(text:string){

 const results:any[]=[]
 const lower=text.toLowerCase()

 rules.rules.forEach((rule:any)=>{
  rule.patterns.forEach((p:string)=>{
   if(lower.includes(p)){
    results.push({
     rule:rule.name,
     severity:rule.severity,
     trigger:p
    })
   }
  })
 })

 return results
}
