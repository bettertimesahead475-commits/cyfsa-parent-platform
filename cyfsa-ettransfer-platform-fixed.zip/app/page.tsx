
export default function Home(){
 return(
  <main>
   <h1>Ontario Parent Defense Platform</h1>
   <p>Educational CYFSA document organization and analysis platform.</p>

   <div className="card">
    <h3>Document Analyzer</h3>
    <a href="/analyzer">Open Analyzer →</a>
   </div>

   <div className="card">
    <h3>Resources</h3>
    <a href="/resources">Open Resources →</a>
   </div>

   <div className="card">
    <h3>Lawyer Intake</h3>
    <a href="/lawyer-intake">Open Intake →</a>
   </div>

  </main>
 )
}
